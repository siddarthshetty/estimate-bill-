module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    fontFamily: {
      'sans': ['Inter', 'Roboto', 'Arial', 'sans-serif'],
    },
    extend: {},
  },
  plugins: [],
}